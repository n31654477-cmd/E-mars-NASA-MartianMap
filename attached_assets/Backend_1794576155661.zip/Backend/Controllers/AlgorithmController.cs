
using Backend.Business;
using Backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/path")]
    public class AlgorithmController : ControllerBase
    {
        [HttpPost("shortest")]
        public ActionResult<PathResult> Shortest(
            [FromBody] PathRequest request)
        {
            return ExecutePath(request, () =>
                ShortestPathAlgorithms.FindShortestPathBFS(
                    request.Grid,
                    request.Start,
                    request.End));
        }

        [HttpPost("dijkstra")]
        public ActionResult<PathResult> Dijkstra(
            [FromBody] PathRequest request)
        {
            return ExecutePath(request, () =>
                TheSafestPathsAlgorithms.TheSafestPathDijkstra(
                    request.Grid,
                    request.Start,
                    request.End));
        }

        [HttpPost("astar")]
        public ActionResult<PathResult> AStar(
            [FromBody] PathRequest request)
        {
            return ExecutePath(request, () =>
                TheSafestPathsAlgorithms.FindPathAStar(
                    request.Grid,
                    request.Start,
                    request.End));
        }
        public static PathResult TheSafestPathDijkstra(
                    Cell[][] grid,
                    Point start,
                    Point destination)
        {
            AlgorithmsValidator.ValidateRequest(grid, start, destination);
            AlgorithmsValidator.ValidateNonnegativeWeights(grid);

            int rows = grid.Length;
            int cols = grid[0].Length;

            double[,] distances = InitializeDistances(rows, cols);
            Point[,] parents = new Point[rows, cols];
            bool[,] visited = new bool[rows, cols];

            SortedSet<(double Cost, int Row, int Col)> frontier =
                CreatePriorityQueue();

            distances[start.Row, start.Col] = 0;
            frontier.Add((0, start.Row, start.Col));

            while (frontier.Count > 0)
            {
                var current = frontier.Min;
                frontier.Remove(current);

                int row = current.Row;
                int col = current.Col;

                if (visited[row, col])
                    continue;

                visited[row, col] = true;

                Point currentPoint = new Point
                {
                    Row = row,
                    Col = col
                };

                if (AlgorithmsCommon.AreSamePoint(currentPoint, destination))
                    break;

                foreach (Point neighbor in AlgorithmsCommon.GetNeighbors(currentPoint, rows, cols))
                {
                    int neighborRow = neighbor.Row;
                    int neighborCol = neighbor.Col;

                    if (visited[neighborRow, neighborCol] ||
                        grid[neighborRow][neighborCol].Blocked)
                    {
                        continue;
                    }

                    RelaxEdge(
                        grid,
                        currentPoint,
                        neighbor,
                        distances,
                        parents,
                        frontier);
                }
            }

            List<Point> path = AlgorithmsCommon.ReconstructPath(parents, start, destination);

            if (path.Count == 0)
                return new PathResult();

            return AlgorithmsCommon.BuildResult(
                grid,
                path,
                distances[destination.Row, destination.Col]);
        }

        private static double[,] InitializeDistances(int rows, int cols)
        {
            double[,] distances = new double[rows, cols];

            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                    distances[row, col] = double.PositiveInfinity;
            }

            return distances;
        }

        private static SortedSet<(double Cost, int Row, int Col)> CreatePriorityQueue()
        {
            return new SortedSet<(double Cost, int Row, int Col)>(
                Comparer<(double Cost, int Row, int Col)>.Create((first, second) =>
                {
                    int comparison = first.Cost.CompareTo(second.Cost);

                    if (comparison != 0)
                        return comparison;

                    comparison = first.Row.CompareTo(second.Row);

                    return comparison != 0
                        ? comparison
                        : first.Col.CompareTo(second.Col);
                }));
        }

        private static void RelaxEdge(
            Cell[][] grid,
            Point current,
            Point neighbor,
            double[,] distances,
            Point[,] parents,
            SortedSet<(double Cost, int Row, int Col)> frontier)
        {
            int currentRow = current.Row;
            int currentCol = current.Col;
            int neighborRow = neighbor.Row;
            int neighborCol = neighbor.Col;

            double newCost =
                distances[currentRow, currentCol] +
                grid[neighborRow][neighborCol].DF;

            if (newCost >= distances[neighborRow, neighborCol])
                return;

            double oldCost = distances[neighborRow, neighborCol];

            if (!double.IsPositiveInfinity(oldCost))
                frontier.Remove((oldCost, neighborRow, neighborCol));

            distances[neighborRow, neighborCol] = newCost;
            parents[neighborRow, neighborCol] = current;

            frontier.Add((newCost, neighborRow, neighborCol));
        }

        private ActionResult<PathResult> ExecutePath(
            PathRequest request,
            Func<PathResult> algorithm)
        {
            if (!IsRequestPresent(request))
                return BadRequest("Path request cannot be null.");

            try
            {
                PathResult result = algorithm();

                if (result.Path == null || result.Path.Count == 0)
                    return NotFound("No path was found.");

                return Ok(result);
            }
            catch (ArgumentException exception)
            {
                return BadRequest(exception.Message);
            }
        }

        private static bool IsRequestPresent(PathRequest request)
        {
            return request != null &&
                   request.Grid != null &&
                   request.Start != null &&
                   request.End != null;
        }
    }
}
