using Backend.Business;
using Backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/grid")]
    public class GridController : ControllerBase
    {
        [HttpPost("generate")]
        public ActionResult<GridResult> Generate(
            [FromBody] GenerateGridRequest request)
        {
            if (request == null)
                return BadRequest("Grid request cannot be null.");

            if (!GridRequestIsValid(request))
                return BadRequest(
                    "Grid dimensions and geographic bounds are invalid.");

            Cell[][] cells = GridGenerator.GenerateGrid(request);

            return Ok(new GridResult
            {
                Rows = request.Rows,
                Columns = request.Columns,
                Cells = cells
            });
        }

        private static bool GridRequestIsValid(
            GenerateGridRequest request)
        {
            return request.Rows >= 1 &&
                   request.Rows <= 80 &&
                   request.Columns >= 1 &&
                   request.Columns <= 80 &&

                   double.IsFinite(request.StartLat) &&
                   double.IsFinite(request.EndLat) &&
                   double.IsFinite(request.StartLng) &&
                   double.IsFinite(request.EndLng) &&

                   request.StartLat < request.EndLat &&
                   request.StartLng < request.EndLng;
        }
    }
}