using Backend.Business;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Newtonsoft.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddControllers()
    .AddNewtonsoftJson(options =>
    {
        options.SerializerSettings.ContractResolver =
            new Newtonsoft.Json.Serialization.DefaultContractResolver();
    });

var app = builder.Build();

ConfigureFrontendHosting(app);

app.UseRouting();
app.MapControllers();

app.Run();

static void ConfigureFrontendHosting(WebApplication app)
{
    string frontendPath = Path.GetFullPath(
        Path.Combine(app.Environment.ContentRootPath, "..", "Frontend"));

    Console.WriteLine($"Frontend path: {frontendPath}");
    Console.WriteLine($"Folder exists: {Directory.Exists(frontendPath)}");
    Console.WriteLine($"Index exists: {File.Exists(Path.Combine(frontendPath, "index.html"))}");

    if (!Directory.Exists(frontendPath))
        return;

    PhysicalFileProvider fileProvider = new PhysicalFileProvider(frontendPath);

    app.UseDefaultFiles(new DefaultFilesOptions
    {
        FileProvider = fileProvider
    });

    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = fileProvider
    });
}