# Mars Safest Path Finder — cleaned backend

This folder contains a cleaned version of the backend files supplied in the conversation.

## Structure

- `Controllers/` — HTTP endpoints and HTTP response handling.
- `Business/` — grid generation and path algorithms.
- `Models/` — request, response, and domain models.
- `Program.cs` — ASP.NET Core setup and frontend static-file hosting.

## Preserved API routes

- `POST /api/grid/generate`
- `POST /api/path/astar`
- `POST /api/path/shortest`
- `POST /api/path/bruteforce`
- `POST /api/path/geojson`

The existing JSON property names remain PascalCase.

## Important algorithm notes

1. The supplied executor method `FindLowestCostPathDijkstra` is Dijkstra. The existing `/astar` route is retained for frontend compatibility, but it currently invokes Dijkstra. It is not A*.
2. The supplied executor did not contain a brute-force implementation. The `/bruteforce` route is retained and responds with HTTP 501 rather than pretending another algorithm is brute force.
3. The executor's method names are now used consistently by the controller:
   - `FindShortestPathBFS`
   - `FindLowestCostPathDijkstra`
   - `ExportPathAsGeoJson`

## Integration

Copy these files into the matching locations in your existing backend project. Keep your existing project file and package references.

Required packages already implied by the supplied project:
- ASP.NET Core MVC
- `Microsoft.AspNetCore.Mvc.NewtonsoftJson`
- Newtonsoft.Json

This package is a source cleanup, not a compiled project. The original `.csproj` and target framework were not supplied.
